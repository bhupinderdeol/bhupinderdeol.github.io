import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, type ButtonHTMLAttributes, type PointerEvent } from "react";
import { mountAshvault, type GameApi, type Hud } from "@/game/mount-ashvault";

export const Route = createFileRoute("/")({ component: Home });

const EMPTY: Hud = { health: 100, ammo: 50, kills: 0, phase: "menu", hit: false };

function Home() {
  const hostRef = useRef<HTMLDivElement>(null);
  const apiRef = useRef<GameApi | null>(null);
  const [hud, setHud] = useState<Hud>(EMPTY);

  useEffect(() => {
    const el = hostRef.current;
    if (!el) return;
    const api = mountAshvault(el, setHud);
    apiRef.current = api;
    return () => {
      api.dispose();
      apiRef.current = null;
    };
  }, []);

  const hold = (code: string) => ({
    onPointerDown: (e: PointerEvent<HTMLButtonElement>) => {
      e.preventDefault();
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
      apiRef.current?.setHeld(code, true);
    },
    onPointerUp: (e: PointerEvent<HTMLButtonElement>) => {
      apiRef.current?.setHeld(code, false);
      e.currentTarget.releasePointerCapture?.(e.pointerId);
    },
    onPointerCancel: () => apiRef.current?.setHeld(code, false),
  });

  const playing = hud.phase === "play";

  return (
    <main className="flex h-dvh flex-col bg-bg text-fg">
      <header className="flex shrink-0 items-baseline justify-between px-4 pt-2 pb-1">
        <h1 className="font-display text-2xl font-bold tracking-[0.18em] text-accent">ASHVAULT</h1>
        <p className="font-mono text-[10px] tracking-[0.22em] text-muted">INDUSTRIAL DESCENT</p>
      </header>

      <div className="relative min-h-0 flex-1">
        <div ref={hostRef} className="absolute inset-0" />
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse at center, transparent 42%, rgba(0,0,0,0.55) 100%)",
          }}
        />
        {hud.hit ? <div className="pointer-events-none absolute inset-0 bg-accent/25" /> : null}
        <div className="pointer-events-none absolute top-[42%] left-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2">
          <span className="absolute top-0 left-1/2 h-3 w-px -translate-x-1/2 bg-fg/80" />
          <span className="absolute top-1/2 left-0 h-px w-3 -translate-y-1/2 bg-fg/80" />
        </div>

        <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between px-4 pb-3">
          <Stat label="AMMO" value={String(hud.ammo)} tone="ammo" />
          <Stat label="HEALTH" value={`${Math.round(hud.health)}%`} tone="accent" />
          <Stat label="KILLS" value={String(hud.kills)} tone="fg" />
        </div>

        {playing ? null : (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-bg/80 px-6 text-center">
            <p className="font-display text-5xl font-bold tracking-[0.16em] text-accent">
              {hud.phase === "dead" ? "FLATLINED" : "ASHVAULT"}
            </p>
            <p className="max-w-xs text-xs leading-relaxed text-muted">
              {hud.phase === "dead"
                ? `Kills ${hud.kills}. The vault is still open.`
                : "Swipe the view to look. Move with the pad. Stay in the light and clear the halls."}
            </p>
            <button
              type="button"
              className="bg-accent px-8 py-3 font-display text-lg tracking-[0.2em] text-fg"
              onClick={() => apiRef.current?.start()}
            >
              {hud.phase === "dead" ? "RESPAWN" : "START"}
            </button>
          </div>
        )}
      </div>

      <section className="flex h-[34vh] max-h-60 shrink-0 items-center justify-between border-t border-line bg-panel px-4 pb-3 [@media(pointer:fine)]:hidden">
        <div className="grid grid-cols-3 grid-rows-2 gap-2">
          <span />
          <Pad label="Forward" {...hold("KeyW")}>
            ▲
          </Pad>
          <span />
          <Pad label="Left" {...hold("KeyA")}>
            ◀
          </Pad>
          <Pad label="Back" {...hold("KeyS")}>
            ▼
          </Pad>
          <Pad label="Right" {...hold("KeyD")}>
            ▶
          </Pad>
        </div>
        <div className="flex flex-col items-center gap-3">
          <button
            type="button"
            aria-label="Fire"
            className="flex h-20 w-20 items-center justify-center rounded-full border-2 border-accent bg-accent-deep font-display text-sm tracking-widest text-fg"
            {...hold("ControlLeft")}
          >
            FIRE
          </button>
          <button
            type="button"
            aria-label="Open door"
            className="h-11 w-20 rounded-lg border border-line bg-bg font-display text-sm tracking-widest text-fg"
            {...hold("Space")}
          >
            OPEN
          </button>
        </div>
      </section>
    </main>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: "ammo" | "accent" | "fg" }) {
  const color = tone === "ammo" ? "text-ammo" : tone === "accent" ? "text-accent" : "text-fg";
  return (
    <div className="flex flex-col items-center">
      <span className="text-[9px] tracking-[0.18em] text-muted">{label}</span>
      <span className={`font-display text-2xl font-bold ${color}`}>{value}</span>
    </div>
  );
}

function Pad({
  label,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return (
    <button
      type="button"
      aria-label={label}
      className="flex h-12 w-12 items-center justify-center rounded-lg border border-line bg-bg text-fg"
      {...rest}
    >
      {children}
    </button>
  );
}
