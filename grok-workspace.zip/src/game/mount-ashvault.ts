import * as THREE from "three";

export type Phase = "menu" | "play" | "dead";

export type Hud = {
  health: number;
  ammo: number;
  kills: number;
  phase: Phase;
  hit: boolean;
};

export type GameApi = {
  start: () => void;
  setHeld: (code: string, down: boolean) => void;
  dispose: () => void;
};

const CELL = 4;
const WALL_H = 3.2;
const EYE = 1.62;
const RADIUS = 0.38;
const MOVE = 4.6;
const LOOK = 0.0024;
const TOUCH_LOOK = 0.0055;

const ROWS = [
  "########################",
  "#......................#",
  "#S.....................#",
  "#..######..######..E...#",
  "#..#....#..#....#......#",
  "#..#..E.#..#....#......#",
  "#..#....####....D......#",
  "#..#............#......#",
  "#..##############......#",
  "#..........E...........#",
  "#......................#",
  "#..##################..#",
  "#........E.............#",
  "#......................#",
  "########################",
];

const MAP_H = ROWS.length;
const MAP_W = ROWS[0]!.length;

type Enemy = {
  mesh: THREE.Group;
  x: number;
  z: number;
  hp: number;
  alive: boolean;
  flash: number;
  body: THREE.MeshStandardMaterial;
};

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys: (codes: string[]) => void;
      getPos: () => { x: number; z: number };
    };
  }
}

function tex(paint: (g: CanvasRenderingContext2D, s: number) => void, repeatX = 1, repeatY = 1) {
  const s = 128;
  const c = document.createElement("canvas");
  c.width = s;
  c.height = s;
  const g = c.getContext("2d");
  if (!g) throw new Error("canvas");
  paint(g, s);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = THREE.RepeatWrapping;
  t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeatX, repeatY);
  t.anisotropy = 4;
  return t;
}

function cellChar(c: number, r: number) {
  if (r < 0 || c < 0 || r >= MAP_H || c >= MAP_W) return "#";
  return ROWS[r]![c]!;
}

export function mountAshvault(host: HTMLElement, onHud: (h: Hud) => void): GameApi {
  const keys = new Set<string>();
  const doors = new Map<string, { mesh: THREE.Mesh; open: number; solid: boolean }>();
  const enemies: Enemy[] = [];

  let phase: Phase = "menu";
  let health = 100;
  let ammo = 50;
  let kills = 0;
  let hitFlash = 0;
  let invuln = 0;
  let fireCd = 0;
  let shake = 0;
  let bob = 0;
  let speed = 0;
  let yaw = Math.PI / 2;
  let pitch = 0;
  let running = true;
  let lastHud = "";

  const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: "high-performance" });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
  renderer.setSize(host.clientWidth, host.clientHeight);
  renderer.setClearColor(0x1a1612, 1);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  host.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x1a1612);
  scene.fog = new THREE.Fog(0x1a1612, 10, 46);

  const camera = new THREE.PerspectiveCamera(72, 1, 0.08, 80);
  const player = new THREE.Group();
  player.add(camera);
  scene.add(player);

  const flash = new THREE.SpotLight(0xfff1dc, 18, 32, 0.62, 0.42, 1);
  flash.castShadow = true;
  flash.shadow.mapSize.set(512, 512);
  flash.shadow.bias = -0.0004;
  camera.add(flash);
  flash.position.set(0.15, -0.05, 0.1);
  flash.target.position.set(0, -0.08, -1);
  camera.add(flash.target);

  scene.add(new THREE.AmbientLight(0xb9aea2, 0.42));
  const hemi = new THREE.HemisphereLight(0xc8beb0, 0x2a221c, 0.55);
  scene.add(hemi);

  const floorTex = tex((g, s) => {
    g.fillStyle = "#3a342c";
    g.fillRect(0, 0, s, s);
    g.fillStyle = "#2a251f";
    g.fillRect(6, 6, s - 12, s - 12);
    g.strokeStyle = "#4a433a";
    g.strokeRect(1, 1, s - 2, s - 2);
  }, MAP_W, MAP_H);
  const wallTex = tex((g, s) => {
    g.fillStyle = "#4a4038";
    g.fillRect(0, 0, s, s);
    g.fillStyle = "#3a322c";
    for (let y = 0; y < s; y += 16) {
      g.fillRect(0, y, s, 2);
      const off = (y / 16) % 2 === 0 ? 0 : 32;
      for (let x = off; x < s; x += 64) g.fillRect(x, y, 2, 16);
    }
    g.fillStyle = "#6a2a22";
    g.fillRect(8, 70, 18, 6);
  }, 1, 1);
  wallTex.repeat.set(1, 1);

  const floorMat = new THREE.MeshStandardMaterial({ map: floorTex, roughness: 0.92, metalness: 0.04 });
  const wallMat = new THREE.MeshStandardMaterial({ map: wallTex, roughness: 0.86, metalness: 0.08 });
  const ceilMat = new THREE.MeshStandardMaterial({ color: 0x221e1b, roughness: 0.95 });
  const doorMat = new THREE.MeshStandardMaterial({ color: 0x5c4632, roughness: 0.55, metalness: 0.35 });
  const trimMat = new THREE.MeshStandardMaterial({
    color: 0xffb080,
    emissive: 0xff7a3a,
    emissiveIntensity: 0.8,
    roughness: 0.4,
  });

  const floor = new THREE.Mesh(new THREE.PlaneGeometry(MAP_W * CELL, MAP_H * CELL), floorMat);
  floor.rotation.x = -Math.PI / 2;
  floor.position.set((MAP_W * CELL) / 2, 0, (MAP_H * CELL) / 2);
  floor.receiveShadow = true;
  scene.add(floor);

  const ceiling = new THREE.Mesh(new THREE.PlaneGeometry(MAP_W * CELL, MAP_H * CELL), ceilMat);
  ceiling.rotation.x = Math.PI / 2;
  ceiling.position.set((MAP_W * CELL) / 2, WALL_H, (MAP_H * CELL) / 2);
  scene.add(ceiling);

  const wallGeo = new THREE.BoxGeometry(CELL, WALL_H, CELL);
  const wallMesh = new THREE.InstancedMesh(wallGeo, wallMat, MAP_W * MAP_H);
  wallMesh.castShadow = true;
  wallMesh.receiveShadow = true;
  const dummy = new THREE.Object3D();
  let wallCount = 0;

  let spawnX = CELL * 2.5;
  let spawnZ = CELL * 2.5;

  for (let r = 0; r < MAP_H; r++) {
    for (let c = 0; c < MAP_W; c++) {
      const ch = cellChar(c, r);
      const x = c * CELL + CELL / 2;
      const z = r * CELL + CELL / 2;
      if (ch === "S") {
        spawnX = x;
        spawnZ = z;
      }
      if (ch === "#") {
        dummy.position.set(x, WALL_H / 2, z);
        dummy.scale.set(1, 1, 1);
        dummy.rotation.set(0, 0, 0);
        dummy.updateMatrix();
        wallMesh.setMatrixAt(wallCount++, dummy.matrix);
      } else if (ch === "D") {
        const mesh = new THREE.Mesh(new THREE.BoxGeometry(CELL * 0.96, WALL_H * 0.92, 0.28), doorMat);
        mesh.position.set(x, WALL_H * 0.46, z);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        scene.add(mesh);
        doors.set(`${c},${r}`, { mesh, open: 0, solid: true });
      } else if (ch === "E") {
        enemies.push(makeEnemy(x, z));
      }
      if ((c + r) % 5 === 0 && ch !== "#") {
        const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.08, 0.7), trimMat);
        lamp.position.set(x, WALL_H - 0.06, z);
        scene.add(lamp);
        const pl = new THREE.PointLight(0xffc9a0, 1.35, 11, 1.4);
        pl.position.set(x, WALL_H - 0.3, z);
        scene.add(pl);
      }
    }
  }
  wallMesh.count = wallCount;
  wallMesh.instanceMatrix.needsUpdate = true;
  scene.add(wallMesh);

  function makeEnemy(x: number, z: number): Enemy {
    const group = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({
      color: 0x6e2c24,
      roughness: 0.62,
      metalness: 0.05,
      emissive: 0x1a0604,
    });
    const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.38, 0.7, 4, 8), bodyMat);
    torso.castShadow = true;
    torso.position.y = 1.15;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.26, 10, 8), bodyMat);
    head.position.y = 1.85;
    head.castShadow = true;
    const eyeMat = new THREE.MeshStandardMaterial({
      color: 0xff4010,
      emissive: 0xff4010,
      emissiveIntensity: 2,
    });
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 6), eyeMat);
    const eyeR = eyeL.clone();
    eyeL.position.set(-0.09, 1.88, 0.2);
    eyeR.position.set(0.09, 1.88, 0.2);
    group.add(torso, head, eyeL, eyeR);
    group.position.set(x, 0, z);
    scene.add(group);
    return { mesh: group, x, z, hp: 70, alive: true, flash: 0, body: bodyMat };
  }

  const gunScene = new THREE.Scene();
  const gunCam = new THREE.PerspectiveCamera(50, 1, 0.05, 10);
  const gun = new THREE.Group();
  const steel = new THREE.MeshStandardMaterial({ color: 0x2c2e33, metalness: 0.55, roughness: 0.38 });
  const grip = new THREE.MeshStandardMaterial({ color: 0x4a3020, roughness: 0.8 });
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.16, 0.55), steel);
  const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.07, 0.42), steel);
  barrel.position.set(0, 0.08, -0.38);
  const handle = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.22, 0.12), grip);
  handle.position.set(0, -0.16, 0.12);
  handle.rotation.x = 0.35;
  const muzzle = new THREE.Mesh(
    new THREE.SphereGeometry(0.06, 8, 6),
    new THREE.MeshBasicMaterial({ color: 0xffe7a0 }),
  );
  muzzle.position.set(0, 0.08, -0.6);
  muzzle.visible = false;
  gun.add(body, barrel, handle, muzzle);
  gun.position.set(0.34, -0.32, -0.72);
  gunCam.add(gun);
  gunScene.add(gunCam);
  const gunLight = new THREE.PointLight(0xffe0a0, 0, 2);
  gun.add(gunLight);

  let spawnYaw = -Math.PI / 2;
  placePlayer(spawnX, spawnZ, spawnYaw);

  function placePlayer(x: number, z: number, nextYaw: number) {
    player.position.set(x, EYE, z);
    yaw = nextYaw;
    pitch = 0;
    player.rotation.y = yaw;
    camera.rotation.x = 0;
  }

  function blocked(x: number, z: number) {
    const samples: Array<[number, number]> = [
      [x, z],
      [x + RADIUS, z],
      [x - RADIUS, z],
      [x, z + RADIUS],
      [x, z - RADIUS],
    ];
    for (const [sx, sz] of samples) {
      const c = Math.floor(sx / CELL);
      const r = Math.floor(sz / CELL);
      const ch = cellChar(c, r);
      if (ch === "#") return true;
      if (ch === "D") {
        const d = doors.get(`${c},${r}`);
        if (!d || d.solid) return true;
      }
    }
    return false;
  }

  function tryMove(dx: number, dz: number) {
    const nx = player.position.x + dx;
    const nz = player.position.z + dz;
    if (!blocked(nx, player.position.z)) player.position.x = nx;
    if (!blocked(player.position.x, nz)) player.position.z = nz;
  }

  function wallDistance(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number) {
    let t = 0.2;
    for (let i = 0; i < 80; i++) {
      t += 0.25;
      const x = ox + dx * t;
      const y = oy + dy * t;
      const z = oz + dz * t;
      if (y < 0.05 || y > WALL_H - 0.05) return t;
      const c = Math.floor(x / CELL);
      const r = Math.floor(z / CELL);
      const ch = cellChar(c, r);
      if (ch === "#") return t;
      if (ch === "D") {
        const door = doors.get(`${c},${r}`);
        if (!door || door.solid) return t;
      }
      if (t > 36) break;
    }
    return 99;
  }

  const audio = { ctx: null as AudioContext | null };
  function ac() {
    if (!audio.ctx) audio.ctx = new AudioContext();
    if (audio.ctx.state === "suspended") void audio.ctx.resume();
    return audio.ctx;
  }
  function blip(freq: number, dur: number, type: OscillatorType, gain = 0.08) {
    const ctx = ac();
    const t = ctx.currentTime;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    o.frequency.exponentialRampToValueAtTime(Math.max(30, freq * 0.25), t + dur);
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g);
    g.connect(ctx.destination);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  function shoot() {
    if (phase !== "play" || fireCd > 0 || ammo <= 0) {
      if (ammo <= 0 && phase === "play") blip(140, 0.05, "square", 0.04);
      return;
    }
    ammo -= 1;
    fireCd = 0.28;
    shake = 0.12;
    pitch = Math.min(1.15, pitch + 0.03);
    muzzle.visible = true;
    gunLight.intensity = 4;
    blip(160, 0.09, "square", 0.12);
    const dir = new THREE.Vector3();
    camera.getWorldDirection(dir);
    const origin = new THREE.Vector3();
    camera.getWorldPosition(origin);
    const wallT = wallDistance(origin.x, origin.y, origin.z, dir.x, dir.y, dir.z);
    let best: Enemy | null = null;
    let bestT = wallT;
    for (const en of enemies) {
      if (!en.alive) continue;
      const ex = en.x - origin.x;
      const ey = 1.3 - origin.y;
      const ez = en.z - origin.z;
      const t = ex * dir.x + ey * dir.y + ez * dir.z;
      if (t < 0.4 || t >= bestT) continue;
      const px = origin.x + dir.x * t;
      const py = origin.y + dir.y * t;
      const pz = origin.z + dir.z * t;
      const ddx = px - en.x;
      const ddy = py - 1.3;
      const ddz = pz - en.z;
      if (ddx * ddx + ddy * ddy + ddz * ddz < 0.55 * 0.55) {
        best = en;
        bestT = t;
      }
    }
    if (best) {
      best.hp -= 28;
      best.flash = 0.16;
      best.body.emissive.setHex(0xffe0d0);
      hitFlash = 0.12;
      blip(90, 0.07, "sawtooth", 0.07);
      if (best.hp <= 0) {
        best.alive = false;
        best.mesh.visible = false;
        kills += 1;
      }
    }
    pushHud(true);
  }

  function openDoor() {
    if (phase !== "play") return;
    const dir = new THREE.Vector3();
    camera.getWorldDirection(dir);
    const x = player.position.x + dir.x * 1.6;
    const z = player.position.z + dir.z * 1.6;
    const key = `${Math.floor(x / CELL)},${Math.floor(z / CELL)}`;
    const door = doors.get(key);
    if (door && door.open < 0.02) {
      door.open = 0.01;
      blip(90, 0.28, "triangle", 0.06);
    }
  }

  function reset() {
    health = 100;
    ammo = 50;
    kills = 0;
    invuln = 1.6;
    fireCd = 0;
    shake = 0;
    for (const en of enemies) {
      en.alive = true;
      en.hp = 70;
      en.flash = 0;
      en.mesh.visible = true;
      en.body.emissive.setHex(0x1a0604);
      en.x = en.mesh.userData.homeX as number;
      en.z = en.mesh.userData.homeZ as number;
      en.mesh.position.set(en.x, 0, en.z);
    }
    for (const d of doors.values()) {
      d.open = 0;
      d.solid = true;
      d.mesh.position.y = WALL_H * 0.46;
    }
    placePlayer(spawnX, spawnZ, spawnYaw);
  }

  for (const en of enemies) {
    en.mesh.userData.homeX = en.x;
    en.mesh.userData.homeZ = en.z;
  }

  function pushHud(force = false) {
    const snap = `${health | 0}|${ammo}|${kills}|${phase}|${hitFlash > 0 ? 1 : 0}`;
    if (!force && snap === lastHud) return;
    lastHud = snap;
    onHud({
      health: Math.max(0, health),
      ammo,
      kills,
      phase,
      hit: hitFlash > 0,
    });
  }

  const fwd = new THREE.Vector3();
  const right = new THREE.Vector3();
  const up = new THREE.Vector3(0, 1, 0);
  let last = performance.now();
  let dbgFrames = 0;
  (window as unknown as { __dbg?: { frames: number; x: number; phase: string; dt: number } }).__dbg = {
    frames: 0,
    x: 0,
    phase: "menu",
    dt: 0,
  };

  function frame() {
    if (!running) return;
    const now = performance.now();
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    dbgFrames += 1;
    const dbg = (window as unknown as { __dbg: { frames: number; x: number; phase: string; dt: number } }).__dbg;
    dbg.frames = dbgFrames;
    dbg.x = player.position.x;
    dbg.phase = phase;
    dbg.dt = dt;

    if (phase === "play") {
      if (invuln > 0) invuln -= dt;
      if (fireCd > 0) fireCd -= dt;
      if (hitFlash > 0) hitFlash -= dt;
      if (shake > 0) shake -= dt;

      player.rotation.y = yaw;
      camera.rotation.x = pitch;
      camera.getWorldDirection(fwd);
      fwd.y = 0;
      if (fwd.lengthSq() > 0.0001) fwd.normalize();
      right.crossVectors(fwd, up).normalize();

      let mx = 0;
      let mz = 0;
      if (keys.has("KeyW") || keys.has("ArrowUp")) {
        mx += fwd.x;
        mz += fwd.z;
      }
      if (keys.has("KeyS") || keys.has("ArrowDown")) {
        mx -= fwd.x;
        mz -= fwd.z;
      }
      if (keys.has("KeyA") || keys.has("ArrowLeft")) {
        mx -= right.x;
        mz -= right.z;
      }
      if (keys.has("KeyD") || keys.has("ArrowRight")) {
        mx += right.x;
        mz += right.z;
      }
      const beforeX = player.position.x;
      const beforeZ = player.position.z;
      const len = Math.hypot(mx, mz);
      if (len > 0) {
        mx = (mx / len) * MOVE * dt;
        mz = (mz / len) * MOVE * dt;
        tryMove(mx, mz);
        bob += dt * 9;
      }
      speed = Math.hypot(player.position.x - beforeX, player.position.z - beforeZ) / Math.max(dt, 0.001);

      const bobY = len > 0 ? Math.sin(bob) * 0.035 : 0;
      const sx = shake > 0 ? (Math.random() - 0.5) * 0.04 : 0;
      const sy = shake > 0 ? (Math.random() - 0.5) * 0.03 : 0;
      camera.position.set(sx, bobY + sy, 0);

      if (keys.has("ControlLeft") || keys.has("ControlRight")) shoot();
      if (keys.has("Space")) openDoor();

      for (const d of doors.values()) {
        if (d.open > 0 && d.open < 1) {
          d.open = Math.min(1, d.open + dt * 1.6);
          d.mesh.position.y = WALL_H * 0.46 + d.open * 2.4;
          if (d.open > 0.72) d.solid = false;
        }
      }

      gun.position.z = -0.72 + (fireCd > 0.18 ? 0.08 : 0);
      gun.rotation.x = Math.sin(bob) * 0.02;
      if (fireCd < 0.2) {
        muzzle.visible = false;
        gunLight.intensity = 0;
      }

      for (const en of enemies) {
        if (!en.alive) continue;
        if (en.flash > 0) {
          en.flash -= dt;
          if (en.flash <= 0) en.body.emissive.setHex(0x1a0604);
        }
        const dx = player.position.x - en.x;
        const dz = player.position.z - en.z;
        const dist = Math.hypot(dx, dz);
        if (dist < 16 && dist > 1.05) {
          const nx = en.x + (dx / dist) * 1.7 * dt;
          const nz = en.z + (dz / dist) * 1.7 * dt;
          if (!blocked(nx, en.z)) en.x = nx;
          if (!blocked(en.x, nz)) en.z = nz;
          en.mesh.position.set(en.x, 0, en.z);
          en.mesh.lookAt(player.position.x, 0, player.position.z);
        }
        if (dist < 1.15 && invuln <= 0) {
          health -= 16 * dt;
          shake = Math.max(shake, 0.08);
          if (health <= 0) {
            health = 0;
            phase = "dead";
            pushHud(true);
          }
        }
      }
    } else {
      yaw += dt * 0.08;
      player.rotation.y = yaw;
      camera.rotation.x = -0.08;
    }

    pushHud();
    renderer.autoClear = true;
    renderer.render(scene, camera);
    renderer.autoClear = false;
    renderer.clearDepth();
    renderer.render(gunScene, gunCam);
    renderer.autoClear = true;
  }

  renderer.setAnimationLoop(frame);

  function resize() {
    const w = host.clientWidth || 1;
    const h = host.clientHeight || 1;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    gunCam.aspect = w / h;
    gunCam.updateProjectionMatrix();
    renderer.setSize(w, h);
  }
  const ro = new ResizeObserver(resize);
  ro.observe(host);
  resize();

  function onMouse(e: MouseEvent) {
    if (phase !== "play") return;
    if (document.pointerLockElement === renderer.domElement || e.buttons === 1) {
      yaw -= e.movementX * LOOK;
      pitch -= e.movementY * LOOK;
      pitch = Math.max(-1.35, Math.min(1.35, pitch));
    }
  }
  let lastTX: number | null = null;
  let lastTY: number | null = null;
  function onTouchStart(e: TouchEvent) {
    if (e.touches.length === 1) {
      lastTX = e.touches[0]!.clientX;
      lastTY = e.touches[0]!.clientY;
    }
  }
  function onTouchMove(e: TouchEvent) {
    if (phase !== "play" || lastTX == null || lastTY == null || e.touches.length !== 1) return;
    const x = e.touches[0]!.clientX;
    const y = e.touches[0]!.clientY;
    yaw -= (x - lastTX) * TOUCH_LOOK;
    pitch -= (y - lastTY) * TOUCH_LOOK;
    pitch = Math.max(-1.35, Math.min(1.35, pitch));
    lastTX = x;
    lastTY = y;
  }
  function onTouchEnd() {
    lastTX = null;
    lastTY = null;
  }
  function onClick() {
    if (phase === "play" && matchMedia("(pointer: fine)").matches) {
      void renderer.domElement.requestPointerLock?.();
    }
  }
  function onKeyDown(e: KeyboardEvent) {
    keys.add(e.code);
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
  }
  function onKeyUp(e: KeyboardEvent) {
    keys.delete(e.code);
  }
  function onBlur() {
    keys.clear();
  }

  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("blur", onBlur);
  renderer.domElement.addEventListener("mousemove", onMouse);
  renderer.domElement.addEventListener("click", onClick);
  renderer.domElement.addEventListener("touchstart", onTouchStart, { passive: true });
  renderer.domElement.addEventListener("touchmove", onTouchMove, { passive: true });
  renderer.domElement.addEventListener("touchend", onTouchEnd);

  window.__controlsTest = {
    getYaw: () => yaw,
    getSpeed: () => speed,
    setKeys: (codes) => {
      keys.clear();
      for (const c of codes) keys.add(c);
    },
    getPos: () => ({ x: player.position.x, z: player.position.z }),
  };

  pushHud(true);

  return {
    start() {
      try {
        ac();
      } catch {
        /* audio optional */
      }
      reset();
      phase = "play";
      pushHud(true);
      if (matchMedia("(pointer: fine)").matches) {
        void renderer.domElement.requestPointerLock?.();
      }
    },
    setHeld(code, down) {
      if (down) keys.add(code);
      else keys.delete(code);
      if (down && code === "ControlLeft") shoot();
      if (down && code === "Space") openDoor();
    },
    dispose() {
      running = false;
      renderer.setAnimationLoop(null);
      ro.disconnect();
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
      renderer.dispose();
      host.replaceChildren();
      if (window.__controlsTest) delete window.__controlsTest;
    },
  };
}
