import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as Timer, S as SpotLight, _ as PointLight, a as CapsuleGeometry, b as Scene, c as Group, d as Mesh, f as MeshBasicMaterial, g as PlaneGeometry, h as PerspectiveCamera, i as CanvasTexture, l as HemisphereLight, m as Object3D, n as AmbientLight, o as Color, p as MeshStandardMaterial, r as BoxGeometry, s as Fog, t as WebGLRenderer, u as InstancedMesh, v as RepeatWrapping, w as Vector3, x as SphereGeometry, y as SRGBColorSpace } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-mI4OvxQ1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var CELL = 4;
var WALL_H = 3.2;
var EYE = 1.62;
var RADIUS = .38;
var MOVE = 4.6;
var LOOK = .0024;
var TOUCH_LOOK = .0055;
var ROWS = [
	"########################",
	"#......................#",
	"#S.....................#",
	"#..######..######..E...#",
	"#..#....#..#....#......#",
	"#..#..E.#..#....#......#",
	"#..#....####....D......#",
	"#..#............#......#",
	"#..##############......#",
	"#..........E...........#",
	"#......................#",
	"#..##################..#",
	"#........E.............#",
	"#......................#",
	"########################"
];
var MAP_H = ROWS.length;
var MAP_W = ROWS[0].length;
function tex(paint, repeatX = 1, repeatY = 1) {
	const s = 128;
	const c = document.createElement("canvas");
	c.width = s;
	c.height = s;
	const g = c.getContext("2d");
	if (!g) throw new Error("canvas");
	paint(g, s);
	const t = new CanvasTexture(c);
	t.colorSpace = SRGBColorSpace;
	t.wrapS = RepeatWrapping;
	t.wrapT = RepeatWrapping;
	t.repeat.set(repeatX, repeatY);
	t.anisotropy = 4;
	return t;
}
function cellChar(c, r) {
	if (r < 0 || c < 0 || r >= MAP_H || c >= MAP_W) return "#";
	return ROWS[r][c];
}
function mountAshvault(host, onHud) {
	const keys = /* @__PURE__ */ new Set();
	const doors = /* @__PURE__ */ new Map();
	const enemies = [];
	let phase = "menu";
	let health = 100;
	let ammo = 50;
	let kills = 0;
	let hitFlash = 0;
	let invuln = 0;
	let fireCd = 0;
	let shake = 0;
	let bob = 0;
	let speed = 0;
	let yaw = Math.PI / 2;
	let pitch = 0;
	let running = true;
	let lastHud = "";
	const renderer = new WebGLRenderer({
		antialias: false,
		powerPreference: "high-performance"
	});
	renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
	renderer.setSize(host.clientWidth, host.clientHeight);
	renderer.setClearColor(1709586, 1);
	renderer.shadowMap.enabled = true;
	renderer.shadowMap.type = 1;
	host.appendChild(renderer.domElement);
	const scene = new Scene();
	scene.background = new Color(1709586);
	scene.fog = new Fog(1709586, 10, 46);
	const camera = new PerspectiveCamera(72, 1, .08, 80);
	const player = new Group();
	player.add(camera);
	scene.add(player);
	const flash = new SpotLight(16773596, 18, 32, .62, .42, 1);
	flash.castShadow = true;
	flash.shadow.mapSize.set(512, 512);
	flash.shadow.bias = -4e-4;
	camera.add(flash);
	flash.position.set(.15, -.05, .1);
	flash.target.position.set(0, -.08, -1);
	camera.add(flash.target);
	scene.add(new AmbientLight(12168866, .42));
	const hemi = new HemisphereLight(13156016, 2761244, .55);
	scene.add(hemi);
	const floorTex = tex((g, s) => {
		g.fillStyle = "#3a342c";
		g.fillRect(0, 0, s, s);
		g.fillStyle = "#2a251f";
		g.fillRect(6, 6, s - 12, s - 12);
		g.strokeStyle = "#4a433a";
		g.strokeRect(1, 1, s - 2, s - 2);
	}, MAP_W, MAP_H);
	const wallTex = tex((g, s) => {
		g.fillStyle = "#4a4038";
		g.fillRect(0, 0, s, s);
		g.fillStyle = "#3a322c";
		for (let y = 0; y < s; y += 16) {
			g.fillRect(0, y, s, 2);
			const off = y / 16 % 2 === 0 ? 0 : 32;
			for (let x = off; x < s; x += 64) g.fillRect(x, y, 2, 16);
		}
		g.fillStyle = "#6a2a22";
		g.fillRect(8, 70, 18, 6);
	}, 1, 1);
	wallTex.repeat.set(1, 1);
	const floorMat = new MeshStandardMaterial({
		map: floorTex,
		roughness: .92,
		metalness: .04
	});
	const wallMat = new MeshStandardMaterial({
		map: wallTex,
		roughness: .86,
		metalness: .08
	});
	const ceilMat = new MeshStandardMaterial({
		color: 2235931,
		roughness: .95
	});
	const doorMat = new MeshStandardMaterial({
		color: 6047282,
		roughness: .55,
		metalness: .35
	});
	const trimMat = new MeshStandardMaterial({
		color: 16756864,
		emissive: 16742970,
		emissiveIntensity: .8,
		roughness: .4
	});
	const floor = new Mesh(new PlaneGeometry(MAP_W * CELL, MAP_H * CELL), floorMat);
	floor.rotation.x = -Math.PI / 2;
	floor.position.set(MAP_W * CELL / 2, 0, MAP_H * CELL / 2);
	floor.receiveShadow = true;
	scene.add(floor);
	const ceiling = new Mesh(new PlaneGeometry(MAP_W * CELL, MAP_H * CELL), ceilMat);
	ceiling.rotation.x = Math.PI / 2;
	ceiling.position.set(MAP_W * CELL / 2, WALL_H, MAP_H * CELL / 2);
	scene.add(ceiling);
	const wallGeo = new BoxGeometry(CELL, WALL_H, CELL);
	const wallMesh = new InstancedMesh(wallGeo, wallMat, MAP_W * MAP_H);
	wallMesh.castShadow = true;
	wallMesh.receiveShadow = true;
	const dummy = new Object3D();
	let wallCount = 0;
	let spawnX = CELL * 2.5;
	let spawnZ = CELL * 2.5;
	for (let r = 0; r < MAP_H; r++) for (let c = 0; c < MAP_W; c++) {
		const ch = cellChar(c, r);
		const x = c * CELL + CELL / 2;
		const z = r * CELL + CELL / 2;
		if (ch === "S") {
			spawnX = x;
			spawnZ = z;
		}
		if (ch === "#") {
			dummy.position.set(x, WALL_H / 2, z);
			dummy.scale.set(1, 1, 1);
			dummy.rotation.set(0, 0, 0);
			dummy.updateMatrix();
			wallMesh.setMatrixAt(wallCount++, dummy.matrix);
		} else if (ch === "D") {
			const mesh = new Mesh(new BoxGeometry(CELL * .96, WALL_H * .92, .28), doorMat);
			mesh.position.set(x, WALL_H * .46, z);
			mesh.castShadow = true;
			mesh.receiveShadow = true;
			scene.add(mesh);
			doors.set(`${c},${r}`, {
				mesh,
				open: 0,
				solid: true
			});
		} else if (ch === "E") enemies.push(makeEnemy(x, z));
		if (ch === "." || ch === "S" || ch === "E") {
			if ((c + r) % 5 === 0 && ch !== "#") {
				const lamp = new Mesh(new BoxGeometry(.7, .08, .7), trimMat);
				lamp.position.set(x, 3.14, z);
				scene.add(lamp);
				const pl = new PointLight(16763296, 1.35, 11, 1.4);
				pl.position.set(x, 2.9000000000000004, z);
				scene.add(pl);
			}
		}
	}
	wallMesh.count = wallCount;
	wallMesh.instanceMatrix.needsUpdate = true;
	scene.add(wallMesh);
	function makeEnemy(x, z) {
		const group = new Group();
		const bodyMat = new MeshStandardMaterial({
			color: 7220260,
			roughness: .62,
			metalness: .05,
			emissive: 1705476
		});
		const torso = new Mesh(new CapsuleGeometry(.38, .7, 4, 8), bodyMat);
		torso.castShadow = true;
		torso.position.y = 1.15;
		const head = new Mesh(new SphereGeometry(.26, 10, 8), bodyMat);
		head.position.y = 1.85;
		head.castShadow = true;
		const eyeMat = new MeshStandardMaterial({
			color: 16728080,
			emissive: 16728080,
			emissiveIntensity: 2
		});
		const eyeL = new Mesh(new SphereGeometry(.05, 6, 6), eyeMat);
		const eyeR = eyeL.clone();
		eyeL.position.set(-.09, 1.88, .2);
		eyeR.position.set(.09, 1.88, .2);
		group.add(torso, head, eyeL, eyeR);
		group.position.set(x, 0, z);
		scene.add(group);
		return {
			mesh: group,
			x,
			z,
			hp: 70,
			alive: true,
			flash: 0,
			body: bodyMat
		};
	}
	const gunScene = new Scene();
	const gunCam = new PerspectiveCamera(50, 1, .05, 10);
	const gun = new Group();
	const steel = new MeshStandardMaterial({
		color: 2895411,
		metalness: .55,
		roughness: .38
	});
	const grip = new MeshStandardMaterial({
		color: 4861984,
		roughness: .8
	});
	const body = new Mesh(new BoxGeometry(.12, .16, .55), steel);
	const barrel = new Mesh(new BoxGeometry(.07, .07, .42), steel);
	barrel.position.set(0, .08, -.38);
	const handle = new Mesh(new BoxGeometry(.09, .22, .12), grip);
	handle.position.set(0, -.16, .12);
	handle.rotation.x = .35;
	const muzzle = new Mesh(new SphereGeometry(.06, 8, 6), new MeshBasicMaterial({ color: 16770976 }));
	muzzle.position.set(0, .08, -.6);
	muzzle.visible = false;
	gun.add(body, barrel, handle, muzzle);
	gun.position.set(.34, -.32, -.72);
	gunCam.add(gun);
	gunScene.add(gunCam);
	const gunLight = new PointLight(16769184, 0, 2);
	gun.add(gunLight);
	let spawnYaw = Math.PI / 2;
	placePlayer(spawnX, spawnZ, spawnYaw);
	function placePlayer(x, z, nextYaw) {
		player.position.set(x, EYE, z);
		yaw = nextYaw;
		pitch = 0;
		player.rotation.y = yaw;
		camera.rotation.x = 0;
	}
	function blocked(x, z) {
		const samples = [
			[x, z],
			[x + RADIUS, z],
			[x - RADIUS, z],
			[x, z + RADIUS],
			[x, z - RADIUS]
		];
		for (const [sx, sz] of samples) {
			const c = Math.floor(sx / CELL);
			const r = Math.floor(sz / CELL);
			const ch = cellChar(c, r);
			if (ch === "#") return true;
			if (ch === "D") {
				const d = doors.get(`${c},${r}`);
				if (!d || d.solid) return true;
			}
		}
		return false;
	}
	function tryMove(dx, dz) {
		const nx = player.position.x + dx;
		const nz = player.position.z + dz;
		if (!blocked(nx, player.position.z)) player.position.x = nx;
		if (!blocked(player.position.x, nz)) player.position.z = nz;
	}
	function wallDistance(ox, oy, oz, dx, dy, dz) {
		let t = .2;
		for (let i = 0; i < 80; i++) {
			t += .25;
			const x = ox + dx * t;
			const y = oy + dy * t;
			const z = oz + dz * t;
			if (y < .05 || y > 3.1500000000000004) return t;
			const c = Math.floor(x / CELL);
			const r = Math.floor(z / CELL);
			const ch = cellChar(c, r);
			if (ch === "#") return t;
			if (ch === "D") {
				const door = doors.get(`${c},${r}`);
				if (!door || door.solid) return t;
			}
			if (t > 36) break;
		}
		return 99;
	}
	const audio = { ctx: null };
	function ac() {
		if (!audio.ctx) audio.ctx = new AudioContext();
		if (audio.ctx.state === "suspended") audio.ctx.resume();
		return audio.ctx;
	}
	function blip(freq, dur, type, gain = .08) {
		const ctx = ac();
		const t = ctx.currentTime;
		const o = ctx.createOscillator();
		const g = ctx.createGain();
		o.type = type;
		o.frequency.setValueAtTime(freq, t);
		o.frequency.exponentialRampToValueAtTime(Math.max(30, freq * .25), t + dur);
		g.gain.setValueAtTime(gain, t);
		g.gain.exponentialRampToValueAtTime(.001, t + dur);
		o.connect(g);
		g.connect(ctx.destination);
		o.start(t);
		o.stop(t + dur + .02);
	}
	function shoot() {
		if (phase !== "play" || fireCd > 0 || ammo <= 0) {
			if (ammo <= 0 && phase === "play") blip(140, .05, "square", .04);
			return;
		}
		ammo -= 1;
		fireCd = .28;
		shake = .12;
		pitch = Math.min(1.15, pitch + .03);
		muzzle.visible = true;
		gunLight.intensity = 4;
		blip(160, .09, "square", .12);
		const dir = new Vector3();
		camera.getWorldDirection(dir);
		const origin = new Vector3();
		camera.getWorldPosition(origin);
		const wallT = wallDistance(origin.x, origin.y, origin.z, dir.x, dir.y, dir.z);
		let best = null;
		let bestT = wallT;
		for (const en of enemies) {
			if (!en.alive) continue;
			const ex = en.x - origin.x;
			const ey = 1.3 - origin.y;
			const ez = en.z - origin.z;
			const t = ex * dir.x + ey * dir.y + ez * dir.z;
			if (t < .4 || t >= bestT) continue;
			const px = origin.x + dir.x * t;
			const py = origin.y + dir.y * t;
			const pz = origin.z + dir.z * t;
			const ddx = px - en.x;
			const ddy = py - 1.3;
			const ddz = pz - en.z;
			if (ddx * ddx + ddy * ddy + ddz * ddz < .55 * .55) {
				best = en;
				bestT = t;
			}
		}
		if (best) {
			best.hp -= 28;
			best.flash = .16;
			best.body.emissive.setHex(16769232);
			hitFlash = .12;
			blip(90, .07, "sawtooth", .07);
			if (best.hp <= 0) {
				best.alive = false;
				best.mesh.visible = false;
				kills += 1;
			}
		}
		pushHud(true);
	}
	function openDoor() {
		if (phase !== "play") return;
		const dir = new Vector3();
		camera.getWorldDirection(dir);
		const x = player.position.x + dir.x * 1.6;
		const z = player.position.z + dir.z * 1.6;
		const key = `${Math.floor(x / CELL)},${Math.floor(z / CELL)}`;
		const door = doors.get(key);
		if (door && door.open < .02) {
			door.open = .01;
			blip(90, .28, "triangle", .06);
		}
	}
	function reset() {
		health = 100;
		ammo = 50;
		kills = 0;
		invuln = 1.6;
		fireCd = 0;
		shake = 0;
		for (const en of enemies) {
			en.alive = true;
			en.hp = 70;
			en.flash = 0;
			en.mesh.visible = true;
			en.body.emissive.setHex(1705476);
			en.x = en.mesh.userData.homeX;
			en.z = en.mesh.userData.homeZ;
			en.mesh.position.set(en.x, 0, en.z);
		}
		for (const d of doors.values()) {
			d.open = 0;
			d.solid = true;
			d.mesh.position.y = WALL_H * .46;
		}
		placePlayer(spawnX, spawnZ, spawnYaw);
	}
	for (const en of enemies) {
		en.mesh.userData.homeX = en.x;
		en.mesh.userData.homeZ = en.z;
	}
	function pushHud(force = false) {
		const snap = `${health | 0}|${ammo}|${kills}|${phase}|${hitFlash > 0 ? 1 : 0}`;
		if (!force && snap === lastHud) return;
		lastHud = snap;
		onHud({
			health: Math.max(0, health),
			ammo,
			kills,
			phase,
			hit: hitFlash > 0
		});
	}
	const fwd = new Vector3();
	const right = new Vector3();
	const up = new Vector3(0, 1, 0);
	const timer = new Timer();
	timer.connect(document);
	function frame() {
		if (!running) return;
		timer.update();
		const dt = Math.min(.05, timer.getDelta());
		if (phase === "play") {
			if (invuln > 0) invuln -= dt;
			if (fireCd > 0) fireCd -= dt;
			if (hitFlash > 0) hitFlash -= dt;
			if (shake > 0) shake -= dt;
			player.rotation.y = yaw;
			camera.rotation.x = pitch;
			camera.getWorldDirection(fwd);
			fwd.y = 0;
			if (fwd.lengthSq() > 1e-4) fwd.normalize();
			right.crossVectors(fwd, up).normalize();
			let mx = 0;
			let mz = 0;
			if (keys.has("KeyW") || keys.has("ArrowUp")) {
				mx += fwd.x;
				mz += fwd.z;
			}
			if (keys.has("KeyS") || keys.has("ArrowDown")) {
				mx -= fwd.x;
				mz -= fwd.z;
			}
			if (keys.has("KeyA") || keys.has("ArrowLeft")) {
				mx -= right.x;
				mz -= right.z;
			}
			if (keys.has("KeyD") || keys.has("ArrowRight")) {
				mx += right.x;
				mz += right.z;
			}
			const beforeX = player.position.x;
			const beforeZ = player.position.z;
			const len = Math.hypot(mx, mz);
			if (len > 0) {
				mx = mx / len * MOVE * dt;
				mz = mz / len * MOVE * dt;
				tryMove(mx, mz);
				bob += dt * 9;
			}
			speed = Math.hypot(player.position.x - beforeX, player.position.z - beforeZ) / Math.max(dt, .001);
			const bobY = len > 0 ? Math.sin(bob) * .035 : 0;
			const sx = shake > 0 ? (Math.random() - .5) * .04 : 0;
			const sy = shake > 0 ? (Math.random() - .5) * .03 : 0;
			camera.position.set(sx, bobY + sy, 0);
			if (keys.has("ControlLeft") || keys.has("ControlRight")) shoot();
			if (keys.has("Space")) openDoor();
			for (const d of doors.values()) if (d.open > 0 && d.open < 1) {
				d.open = Math.min(1, d.open + dt * 1.6);
				d.mesh.position.y = WALL_H * .46 + d.open * 2.4;
				if (d.open > .72) d.solid = false;
			}
			gun.position.z = -.72 + (fireCd > .18 ? .08 : 0);
			gun.rotation.x = Math.sin(bob) * .02;
			if (fireCd < .2) {
				muzzle.visible = false;
				gunLight.intensity = 0;
			}
			for (const en of enemies) {
				if (!en.alive) continue;
				if (en.flash > 0) {
					en.flash -= dt;
					if (en.flash <= 0) en.body.emissive.setHex(1705476);
				}
				const dx = player.position.x - en.x;
				const dz = player.position.z - en.z;
				const dist = Math.hypot(dx, dz);
				if (dist < 16 && dist > 1.05) {
					const nx = en.x + dx / dist * 1.7 * dt;
					const nz = en.z + dz / dist * 1.7 * dt;
					if (!blocked(nx, en.z)) en.x = nx;
					if (!blocked(en.x, nz)) en.z = nz;
					en.mesh.position.set(en.x, 0, en.z);
					en.mesh.lookAt(player.position.x, 0, player.position.z);
				}
				if (dist < 1.15 && invuln <= 0) {
					health -= 16 * dt;
					shake = Math.max(shake, .08);
					if (health <= 0) {
						health = 0;
						phase = "dead";
						pushHud(true);
					}
				}
			}
		} else {
			yaw += dt * .08;
			player.rotation.y = yaw;
			camera.rotation.x = -.08;
		}
		pushHud();
		renderer.autoClear = true;
		renderer.render(scene, camera);
		renderer.autoClear = false;
		renderer.clearDepth();
		renderer.render(gunScene, gunCam);
		renderer.autoClear = true;
	}
	renderer.setAnimationLoop(frame);
	function resize() {
		const w = host.clientWidth || 1;
		const h = host.clientHeight || 1;
		camera.aspect = w / h;
		camera.updateProjectionMatrix();
		gunCam.aspect = w / h;
		gunCam.updateProjectionMatrix();
		renderer.setSize(w, h);
	}
	const ro = new ResizeObserver(resize);
	ro.observe(host);
	resize();
	function onMouse(e) {
		if (phase !== "play") return;
		if (document.pointerLockElement === renderer.domElement || e.buttons === 1) {
			yaw -= e.movementX * LOOK;
			pitch -= e.movementY * LOOK;
			pitch = Math.max(-1.35, Math.min(1.35, pitch));
		}
	}
	let lastTX = null;
	let lastTY = null;
	function onTouchStart(e) {
		if (e.touches.length === 1) {
			lastTX = e.touches[0].clientX;
			lastTY = e.touches[0].clientY;
		}
	}
	function onTouchMove(e) {
		if (phase !== "play" || lastTX == null || lastTY == null || e.touches.length !== 1) return;
		const x = e.touches[0].clientX;
		const y = e.touches[0].clientY;
		yaw -= (x - lastTX) * TOUCH_LOOK;
		pitch -= (y - lastTY) * TOUCH_LOOK;
		pitch = Math.max(-1.35, Math.min(1.35, pitch));
		lastTX = x;
		lastTY = y;
	}
	function onTouchEnd() {
		lastTX = null;
		lastTY = null;
	}
	function onClick() {
		if (phase === "play" && matchMedia("(pointer: fine)").matches) renderer.domElement.requestPointerLock?.();
	}
	function onKeyDown(e) {
		keys.add(e.code);
		if ([
			"Space",
			"ArrowUp",
			"ArrowDown",
			"ArrowLeft",
			"ArrowRight"
		].includes(e.code)) e.preventDefault();
	}
	function onKeyUp(e) {
		keys.delete(e.code);
	}
	function onBlur() {
		keys.clear();
	}
	window.addEventListener("keydown", onKeyDown);
	window.addEventListener("keyup", onKeyUp);
	window.addEventListener("blur", onBlur);
	renderer.domElement.addEventListener("mousemove", onMouse);
	renderer.domElement.addEventListener("click", onClick);
	renderer.domElement.addEventListener("touchstart", onTouchStart, { passive: true });
	renderer.domElement.addEventListener("touchmove", onTouchMove, { passive: true });
	renderer.domElement.addEventListener("touchend", onTouchEnd);
	window.__controlsTest = {
		getYaw: () => yaw,
		getSpeed: () => speed,
		setKeys: (codes) => {
			keys.clear();
			for (const c of codes) keys.add(c);
		},
		getPos: () => ({
			x: player.position.x,
			z: player.position.z
		})
	};
	pushHud(true);
	return {
		start() {
			try {
				ac();
			} catch {}
			reset();
			phase = "play";
			pushHud(true);
			if (matchMedia("(pointer: fine)").matches) renderer.domElement.requestPointerLock?.();
		},
		setHeld(code, down) {
			if (down) keys.add(code);
			else keys.delete(code);
			if (down && code === "ControlLeft") shoot();
			if (down && code === "Space") openDoor();
		},
		dispose() {
			running = false;
			renderer.setAnimationLoop(null);
			ro.disconnect();
			window.removeEventListener("keydown", onKeyDown);
			window.removeEventListener("keyup", onKeyUp);
			window.removeEventListener("blur", onBlur);
			renderer.dispose();
			host.replaceChildren();
			if (window.__controlsTest) delete window.__controlsTest;
		}
	};
}
var EMPTY = {
	health: 100,
	ammo: 50,
	kills: 0,
	phase: "menu",
	hit: false
};
function Home() {
	const hostRef = (0, import_react.useRef)(null);
	const apiRef = (0, import_react.useRef)(null);
	const [hud, setHud] = (0, import_react.useState)(EMPTY);
	(0, import_react.useEffect)(() => {
		const el = hostRef.current;
		if (!el) return;
		const api = mountAshvault(el, setHud);
		apiRef.current = api;
		return () => {
			api.dispose();
			apiRef.current = null;
		};
	}, []);
	const hold = (code) => ({
		onPointerDown: (e) => {
			e.preventDefault();
			e.currentTarget.setPointerCapture(e.pointerId);
			apiRef.current?.setHeld(code, true);
		},
		onPointerUp: (e) => {
			apiRef.current?.setHeld(code, false);
			e.currentTarget.releasePointerCapture?.(e.pointerId);
		},
		onPointerCancel: () => apiRef.current?.setHeld(code, false)
	});
	const playing = hud.phase === "play";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex shrink-0 items-baseline justify-between px-4 pt-2 pb-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-bold tracking-[0.18em] text-accent",
					children: "ASHVAULT"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[10px] tracking-[0.22em] text-muted",
					children: "INDUSTRIAL DESCENT"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative min-h-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: hostRef,
						className: "absolute inset-0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pointer-events-none absolute inset-0",
						style: { background: "radial-gradient(ellipse at center, transparent 42%, rgba(0,0,0,0.55) 100%)" }
					}),
					hud.hit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-accent/25" }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-none absolute top-[42%] left-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-0 left-1/2 h-3 w-px -translate-x-1/2 bg-fg/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1/2 left-0 h-px w-3 -translate-y-1/2 bg-fg/80" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between px-4 pb-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "AMMO",
								value: String(hud.ammo),
								tone: "ammo"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "HEALTH",
								value: `${Math.round(hud.health)}%`,
								tone: "accent"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "KILLS",
								value: String(hud.kills),
								tone: "fg"
							})
						]
					}),
					playing ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-0 flex flex-col items-center justify-center gap-4 bg-bg/80 px-6 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-5xl font-bold tracking-[0.16em] text-accent",
								children: hud.phase === "dead" ? "FLATLINED" : "ASHVAULT"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "max-w-xs text-xs leading-relaxed text-muted",
								children: hud.phase === "dead" ? `Kills ${hud.kills}. The vault is still open.` : "Swipe the view to look. Move with the pad. Stay in the light and clear the halls."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "bg-accent px-8 py-3 font-display text-lg tracking-[0.2em] text-fg",
								onClick: () => apiRef.current?.start(),
								children: hud.phase === "dead" ? "RESPAWN" : "START"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex h-[34vh] max-h-60 shrink-0 items-center justify-between border-t border-line bg-panel px-4 pb-3 [@media(pointer:fine)]:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-3 grid-rows-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pad, {
							label: "Forward",
							...hold("KeyW"),
							children: "▲"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pad, {
							label: "Left",
							...hold("KeyA"),
							children: "◀"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pad, {
							label: "Back",
							...hold("KeyS"),
							children: "▼"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pad, {
							label: "Right",
							...hold("KeyD"),
							children: "▶"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Fire",
						className: "flex h-20 w-20 items-center justify-center rounded-full border-2 border-accent bg-accent-deep font-display text-sm tracking-widest text-fg",
						...hold("ControlLeft"),
						children: "FIRE"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Open door",
						className: "h-11 w-20 rounded-lg border border-line bg-bg font-display text-sm tracking-widest text-fg",
						...hold("Space"),
						children: "OPEN"
					})]
				})]
			})
		]
	});
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[9px] tracking-[0.18em] text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `font-display text-2xl font-bold ${tone === "ammo" ? "text-ammo" : tone === "accent" ? "text-accent" : "text-fg"}`,
			children: value
		})]
	});
}
function Pad({ label, children, ...rest }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		className: "flex h-12 w-12 items-center justify-center rounded-lg border border-line bg-bg text-fg",
		...rest,
		children
	});
}
//#endregion
export { Home as component };
